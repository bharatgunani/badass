var config = {
    map: {
        '*': {
            amasty_acart_schedule: 'Amasty_Acart/js/schedule',
            amasty_acart_test: 'Amasty_Acart/js/test'
        }
    },
    deps: [
    ]
};