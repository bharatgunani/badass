var config = {
    map: {
        '*': {
            'mirasvit/rewards/onestepcheckout/securecheckout': 'Mirasvit_Rewards/js/onestepcheckout/securecheckout',
            'pageCache': 'Mirasvit_Rewards/js/pagecache',
            'Magento_Checkout/js/action/select-payment-method': 'Mirasvit_Rewards/js/checkout/override/select-payment-method',
        }
    }

};
