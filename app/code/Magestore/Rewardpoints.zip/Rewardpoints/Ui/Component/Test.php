<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Rewardpoints\Ui\Component;

use Magento\Ui\Component\Form\Field;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
/**
 * Class Options
 */
class Test extends Field
{
    public function render()
    {
        return 'bsdffsf';
    }
    public function toHtml()
    {
        return 'hhhhh';
    }

}
