/*
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

var config = {
    map: {
        '*': {
            'magestore/webposLogin': 'Magestore_Webpos/js/login',
            'magestore/jqueryToaster': 'Magestore_Webpos/js/jquery.toaster'
        }
    },
    paths: {
    }
};
