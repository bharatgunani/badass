<?php
/**
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

namespace Magestore\Webpos\Block\Checkout;

/**
 * class \Magestore\Webpos\Block\AbstractBlock
 * 
 * Web POS abstract block  
 * Methods:
 * 
 * @category    Magestore
 * @package     Magestore\Webpos\Block
 * @module      Webpos
 * @author      Magestore Developer
 */
class Cart extends \Magestore\Webpos\Block\AbstractBlock
{

}
