<?php
namespace Magestore\Webpos\Api\Catalog;

interface SwatchRepositoryInterface
{
    /**
     *
     * @param
     * @return \Magestore\Webpos\Api\Data\Catalog\SwatchResultInterface
     */
    public function getList();

}
