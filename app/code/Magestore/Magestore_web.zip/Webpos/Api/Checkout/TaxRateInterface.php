<?php

/**
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */
namespace Magestore\Webpos\Api\Checkout;

/**
 * Interface TaxRateInterface
 * @package Magestore\Webpos\Api\Checkout
 */
interface TaxRateInterface extends \Magento\Tax\Api\TaxRateRepositoryInterface
{

}
