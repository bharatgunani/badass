<?php

/**
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */
namespace Magestore\Webpos\Model\Staff\Acl\AclResource;

/**
 * Class Provider
 * @package Magestore\Webpos\Model\Staff\Acl\AclResource
 */
class Provider extends \Magento\Framework\Acl\AclResource\Provider implements ProviderInterface
{

}
