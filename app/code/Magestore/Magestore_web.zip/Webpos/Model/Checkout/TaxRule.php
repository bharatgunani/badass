<?php

/**
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */
namespace Magestore\Webpos\Model\Checkout;

class TaxRule extends \Magento\Tax\Model\TaxRuleRepository
    implements \Magestore\Webpos\Api\Checkout\TaxRuleInterface
{
    
}
