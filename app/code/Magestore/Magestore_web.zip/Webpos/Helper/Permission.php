<?php
/**
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

namespace Magestore\Webpos\Helper;

    /**
     * class \Magestore\Webpos\Helper\Permission
     *
     * Web POS Permission helper
     * Methods:
     *  getAllCurrentPermission

     *
     * @category    Magestore
     * @package     Magestore_Webpos
     * @module      Webpos
     * @author      Magestore Developer
     */
/**
 * Class Permission
 * @package Magestore\Webpos\Helper
 */
/**
 * Class Permission
 * @package Magestore\Webpos\Helper
 */
class Permission extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var \Magestore\Webpos\Model\Staff\WebPosSessionFactory
     */
    protected $_webposSessionFactory;
    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    protected $_cookieManager;

    /**
     * @var \Magestore\Webpos\Model\Staff\StaffFactory
     */
    protected $_staffFactory;

    /**
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $_timezone;

    /**
     * Permission constructor.
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magestore\Webpos\Model\Staff\WebPosSessionFactory $sessionFactory,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magestore\Webpos\Model\Staff\StaffFactory $staffFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
    ) {
        $this->_objectManager = $objectManager;
        $this->_webposSessionFactory = $sessionFactory;
        $this->_cookieManager = $cookieManager;
        $this->_staffFactory = $staffFactory;
        $this->_coreRegistry = $coreRegistry;
        $this->_timezone = $timezone;
        parent::__construct($context);
    }

    /**
     * @return array
     */
    public function getAllCurrentPermission() {
        $staffModel = $this->getCurrentStaffModel();
        $resourceAccess = array();
        if ($staffModel->getId()) {
            $roleId = $staffModel->getRoleId();
            $authorizationCollection = $this->_objectManager->create('Magestore\Webpos\Model\Staff\AuthorizationRule')
                ->getCollection()->addFieldToFilter('role_id', $roleId);
            foreach ($authorizationCollection as $resource) {
                $resourceAccess[] = $resource->getResourceId();
            }
        }
        return $resourceAccess;
    }

    /**
     * @param $resource
     * @return bool
     */
    public function isAllowResource($resource) {
        $allPermission = $this->getAllCurrentPermission();
        if (in_array($resource, $allPermission)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @return int
     */
    public function getCurrentUser()
    {
        if($this->_coreRegistry->registry('currrent_webpos_staff')) {
            return $this->_coreRegistry->registry('currrent_webpos_staff')->getId();
        }
        $phpSession = $this->_cookieManager->getCookie('WEBPOSSESSION');
        $webposModel = $this->_webposSessionFactory->create()->load($phpSession, 'session_id');
        if ($webposModel->getId()) {
            $logTimeStaff = $webposModel->getData('logged_date');
            $currentTime = $this->_timezone->scopeTimeStamp();
            $logTimeStamp = strtotime($logTimeStaff);
            if (($currentTime - $logTimeStamp) <= $this->getTimeoutSession()) {
                return $webposModel->getStaffId();
            } else {
                $webposModel->delete();
                return 0;
            }
        } else {
            return 0;
        }
    }

    /**
     * @param $phpSession
     * @return int
     */
    public function authorizeSession($phpSession)
    {
        $webposModel = $this->_webposSessionFactory->create()->load($phpSession, 'session_id');
        if(!$this->_coreRegistry->registry('currrent_webpos_staff')) {
            $staff = $this->_objectManager->create('Magestore\Webpos\Model\Staff\Staff')->load($webposModel->getStaffId());
            $this->_coreRegistry->register('currrent_webpos_staff', $staff);
        }
        if ($webposModel->getId()) {
            $logTimeStaff = $webposModel->getData('logged_date');
            $currentTime = $this->_timezone->scopeTimeStamp();
            $logTimeStamp = strtotime($logTimeStaff);
            if (($currentTime - $logTimeStamp) <= $this->getTimeoutSession()) {
                $newLoggedDate =  strftime('%Y-%m-%d %H:%M:%S', $this->_timezone->scopeTimeStamp());
                $webposModel->setData('logged_date', $newLoggedDate);
                $webposModel->save();
                return $webposModel->getStaffId();
            } else {
                $webposModel->delete();
                return 0;
            }
        } else {
            return 0;
        }
    }

    /**
     *
     * @param string $username
     * @param string $password
     * @return string|boolean
     */
    public function login($username, $password) {
        $user = $this->_staffFactory->create();
        if ($user->authenticate($username, $password)) {
            return $user->getId();
        }
        return 0;
    }

    /**
     * @return null
     */
    public function getCurrentStaffModel()
    {
        if($this->_coreRegistry->registry('currrent_webpos_staff')) {
            return $this->_coreRegistry->registry('currrent_webpos_staff');
        }
        $currentId = $this->getCurrentUser();
        $currentModel = $this->_objectManager->create('Magestore\Webpos\Model\Staff\Staff')
            ->load($currentId);
        return $currentModel;
    }

    /**
     * @return int
     */
    public function getCurrentLocation()
    {
        $staff = $this->getCurrentStaffModel();

        return $staff->getLocationId();
    }

    /**
     * Get current location object
     *
     * @return \Magestore\Webpos\Model\Location\Location
     */
    public function getCurrentLocationObject()
    {
        $locationId = $this->getCurrentLocation();
        $locationModel = $this->_objectManager->create('Magestore\Webpos\Model\Location\Location')->load($locationId);

        return $locationModel;
    }

    /**
     * @return int
     */
    public function getCurrentLastOfflineOrderId()
    {
        $staff = $this->getCurrentStaffModel();

        return $staff->getLastOfflineId();
    }

    /**
     * @return int
     */
    public function getTimeoutSession(){
        return $this->scopeConfig->getValue('webpos/general/session_timeout', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * Get maximum discount percent
     *
     * @return float
     */
    public function getMaximumDiscountPercent()
    {
        $maximumDiscount = 100;
        $staff = $this->getCurrentStaffModel();
        $roleId = $staff->getRoleId();
        if($roleId){
            $role = $this->_objectManager->create('Magestore\Webpos\Model\Staff\Role')->load($roleId);
            if($role->getId()){
                $maximumDiscount = ($role->getData("maximum_discount_percent"))?$role->getData("maximum_discount_percent"):100;
            }
        }
        return $maximumDiscount;
    }

    /**
     * @return mixed
     */
    public function isEnablePoleDisplay()
    {
        return (boolean) $this->scopeConfig->getValue('webpos/general/enable_pole_display', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}
