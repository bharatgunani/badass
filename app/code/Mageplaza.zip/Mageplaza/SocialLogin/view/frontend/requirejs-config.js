

var config = {
    map: {
        "*": {
            'Mageplaza_SocialLogin/js/sociallogin': 'Mageplaza_SocialLogin/js/sociallogin',
            'Mageplaza_SocialLogin/js/jquery/jquery.magnific-popup.min': 'Mageplaza_SocialLogin/js/jquery/jquery.magnific-popup.min',
            'Mageplaza_SocialLogin/js/sociallogin/form': 'Mageplaza_SocialLogin/js/sociallogin/form',
        }
    }
};
