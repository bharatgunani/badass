<?php
namespace Mageplaza\SocialLogin\Block\Popup;

 use Magento\Customer\Block\Form\Register;

class Create extends Register
{
	protected function _prepareLayout()
    {
       
    }

}

