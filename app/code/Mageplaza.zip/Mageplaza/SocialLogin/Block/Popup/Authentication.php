<?php
namespace Mageplaza\SocialLogin\Block\Popup;

use Magento\Customer\Block\Form\Login;

class Authentication extends Login
{
	protected function _prepareLayout()
    {
       
    }
}
