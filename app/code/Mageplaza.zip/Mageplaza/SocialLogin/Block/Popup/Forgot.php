<?php
namespace Mageplaza\SocialLogin\Block\Popup;

use Mageplaza\SocialLogin\Block\SocialLogin;

class Forgot extends SocialLogin
{

}
