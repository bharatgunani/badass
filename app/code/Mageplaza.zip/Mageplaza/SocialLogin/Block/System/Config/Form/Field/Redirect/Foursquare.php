<?php

namespace Mageplaza\SocialLogin\Block\System\Config\Form\Field\Redirect;

use Mageplaza\SocialLogin\Block\System\Config\Form\Field\Redirect;

/**
 * Backend system config datetime field renderer
 */
class Foursquare extends Redirect
{
	protected $socialType = 'Foursquare';
}
