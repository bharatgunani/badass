<?php

\Magento\Framework\Component\ComponentRegistrar::register(
     \Magento\Framework\Component\ComponentRegistrar::MODULE,
     'Iksanika_Productmanage',
     __DIR__
 );
