/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            'Magento_Checkout/js/model/shipping-rates-validation-rules':'Magestore_OneStepCheckout/js/model/shipping-rates-validation-rules'
        }
    }
};
