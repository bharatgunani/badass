/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            jscolor: 'Magestore_Giftvoucher/js/jscolor/jscolor',
            uploadimage: 'Magestore_Giftvoucher/js/uploadimage',
            jqueryMediaBox: 'Magestore_Giftvoucher/js/gifttemplate/jquery.media.box',
            'magestore/baseimage': 'Magestore_Giftvoucher/js/gallery/base-image-uploader',
           
        }
    }
};